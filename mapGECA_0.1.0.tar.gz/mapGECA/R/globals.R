utils::globalVariables(c("query_data", "ref_data", "ID_classes","min_sample_size","nosample","num_sigs","col_q" ,"obs_fpp", "row_r"))
